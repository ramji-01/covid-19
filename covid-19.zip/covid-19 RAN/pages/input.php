<?php
		include "../connection.php";
		$ac=$_POST['periyar'];
		$an=$_POST['arapalayam'];
		$d=$_POST['matuthavani'];
		$a=$_POST['koripalayam'];
		$p=$_POST['therkuvasal'];
		$con=$_POST['thiruparankunram'];
		$br=$_POST['new_cases'];
		$bo=$_POST['new_recovery'];
		$bd=$_POST['new_dead'];
		$query="insert into corona_case(C_date,periyar,arapalayam,matuthavani,koripalayam,therkuvasal,thiruparankunram, new_cases, new_recovery, new_dead) values(CURDATE() + INTERVAL 0 DAY,'$ac','$an','$d','$a','$p','$con','$br','$bo','$bd')";
		mysqli_query($conn,$query) or die($query."Can't Connect to Query...");
?>