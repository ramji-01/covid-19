<?php    
include "input.php";    
        
$sql = "select * from corona_case";    
$result = mysqli_query($conn,$sql);    
?>    
<html>    
    <body style="background-color:powderblue;">    
        <link href = "../style.css" type = "text/css" rel = "stylesheet" />    
		<link href = "registration.css" type = "text/css" rel = "stylesheet" />    
		<table width = "100%" border = "1" cellspacing = "1" cellpadding = "1">    
            <tr>    
                <td>Date</td>    
                <td>Periyar</td>    
                <td>Arapalayam</td>    
                <td>Matuthavani</td>    
                <td>Koripalayam</td>    
                <td>Therkuvasal</td>    
				<td>Thiruparankunram</td>
				<td>New Cases</td> 
				<td>New Death</td> 
				<td>New recovery</td>   
            </tr>  
	<?php    
    
		while($row = mysqli_fetch_object($result)){    
    
    
	?>  
			<tr>  
				<td> 
					<?php echo $row->c_date;?>  
				</td>  
				<td>  
					<?php echo $row->periyar;?>  
				</td>  
				<td>  
					<?php echo $row->arapalayam;?>  
				</td>  
				<td>  
					<?php echo $row->matuthavani;?>  
				</td>  
				<td>  
					<?php echo $row->koripalayam;?>  
				</td>  
				<td>  
					<?php echo $row->therkuvasal;?>  
				</td>  
				<td>  
					<?php echo $row->thiruparankunram;?>  
				</td>  
				<td> 
					<?php echo $row->new_cases;?>  
				</td>  
				<td> 
					<?php echo $row->new_recovery;?>  
				</td>  
				<td> 
					<?php echo $row->new_dead;?>  
				</td>  
				
				
			</tr>  
		<?php } ?>  			
        </table>
<?php header('Location: modified1.php')?>;   		
    </body>    
</html>