<?php
$host = "sql104.epizy.com";
$user = "epiz_25842798";
$pwd  = "ej603D3xf9ul";
$db   = "epiz_25842798_dbforum";

$con = mysql_connect($host,$user,$pwd) or die("Could not connect");
mysql_select_db($db,$con) or die("No database");

?>