  
  
  <footer class="py-5 bg-inverse">
        <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; Disaster Fund Management System 2020- Team Angu!</p>
        </div>
        <!-- /.container -->
    </footer>