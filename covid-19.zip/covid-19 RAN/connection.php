<?php  
		$servername = "sql104.epizy.com";  
		$username = "epiz_25842798";  
		$password = "ej603D3xf9ul";  
		$conn = mysqli_connect($servername , $username , $password,"epiz_25842798_test") or die("unable to connect to host"); 
?>   